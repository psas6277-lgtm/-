# OmniNode 6.0 — changelog

- **Registration:** the «Повтори пароль» field could stay collapsed (max-height animation) so «Пароли не совпадают» appeared with nothing to retype. The field is now a plain show/hide block, the form scrolls on short screens, and a hidden confirm field is never compared.
- **Island over other apps (lag):** `FLAG_WATCH_OUTSIDE_TOUCH` made the island run JavaScript on every touch anywhere on the screen. Outside-touch is now watched only while the island is expanded, throttled to 4/s. `backdrop-filter` (does nothing over other windows, only costs GPU) is off in the overlay WebView.
- **Island tap on the player / calls:** a single tap waited 270 ms for a possible double-tap before expanding. It now expands immediately (double-tap track skip stays available as a gesture in Settings → Gestures).
- **AI agent window:** redesigned (header with live «Готов / Работает» pill, permission rows with status dots, example chips, send button, chat-style log). It now opens the native agent loop; the old «Составить план» planner sheet is no longer the entry point.
- **«Скачай Qwen 0.5 / 1.5 / 3»:** commands like «скачай версию 0,5 1,5 и 3» go straight to the on-device model download (queued one by one) and never to app search. If the WebView has no WebGPU, the agent says so instead of opening random apps.
- **Native agent prompt:** rules for model downloads, «найди X в Google» (type only X) and «open only what was asked».

# OmniNode 5.9 — changelog

- **Liquid-glass bottom bar.** Press and hold the bar of the settings centre and drag your finger: the active tab grows into a glass lens that follows the finger on a spring (stretches with speed), shows the tabs magnified in the accent colour, has a refracting rainbow rim with a dark specular slot, and a sheen that shimmers with position and speed. The bar itself turns into lighter glass while pressed. On release the lens springs to the nearest tab, switches the page, shrinks back into the pill, and the pill flashes an accent glow. A plain tap works the same way; a light haptic tick fires when the lens crosses a tab.
- Lens is pure CSS + a small rAF spring loop (no WebGL, no per-frame layout); it is switched off in «Экономный режим» (the bar then behaves as in 5.8).

# OmniNode 5.8 — changelog

- **Graph:** all nodes are now small (38 px), identical, calm grey; no colours or glow. Press / hold animations, spring entrance.
- **Search moved to Settings** (Home tab). The lens under the core and its per-frame position loop are removed (it was a lag source). Better matching: prefix / word / wrong keyboard layout / Russian aliases («ютуб» → YouTube). Result stars pin apps to a quick row.
- **New settings centre** (gear): bottom tab bar Home · Features · Gestures · Appearance · Settings, live island preview (Compact / Expanded, 7 activities), accordion cards, spring toggles and sliders. Every control writes the real island settings; changes are pushed live to the overlay island (`Android.islandCfg`) instead of reloading its WebView.
- **Old settings** are kept («Settings → More»): opaque, graph and island no longer drawn over them; the «Assistant» tab and the cloud / "check" block are removed.
- **Dynamic Island is hidden** while any settings screen is open.
- **From Dynamic Island 1.7.2:** gestures (tap / double / long / 4 swipes → action), per-app notification rules, notification history, brief (time · date · weather via Open-Meteo · battery), pinned apps, text colour and weight, capsule colour / outline, glass density, expansion style / elasticity / speed, schedule, battery saving, shape / size / position, all event toggles.
- **Registration screen** on first launch (e-mail + password, hashed, stored locally); sign-out in Settings.
- **Stability:** MainActivity is `singleTask` (no duplicate app windows), config changes no longer recreate it, permissions are requested once, `applyModes()` is debounced, the core no longer collapses on every island size update, core expand/collapse is debounced.
- Not ported (need Shizuku / native Compose code): Face ID unlock animation, daily steps, headset battery, hotspot client counts.

# OmniNode 5.7 — changelog

- **Dynamic Island, camera:** the dot in the middle of the capsule is gone. The island is anchored to the real cutout (X and Y) with fallbacks (window insets → root insets → Display.getCutout) and remembers the last known cutout. In the overlay window `env(safe-area-inset-top)` is no longer used (it could shift the island twice); the top edge is the same in compact and expanded states, so the island grows downward from the camera.
- **Dynamic Island, glass:** compact island = black capsule with a thin specular rim (blends with the camera); expanded island = liquid glass (layered gradient, saturated blur, gradient rim, highlights). Over other apps Android cannot blur what is behind the window, so the glass is more opaque there for readable text. Glass is turned on once for existing users (Island → Glass Layer still switches it off).
- **Second activity beside the island** (setting «Вторая активность рядом», on by default): e.g. music + timer/stopwatch/call/navigation, tap the circle to pin it.
- **Graph:** larger node circles (56 px), readable labels (11.5 px on a darker plate), per-node accent colours, animated connection lines; per-node backdrop blur removed (main source of lag), camera transform is written only when it changes.
- **New nodes:** Music (players), Processes (flashlight, Pomodoro, focus, voice, permissions, island, core overlay — real app functions), Apps (Gmail, Maps, Calendar, Photos, Drive, Play, YouTube, Telegram). Only missing sections are added; nothing is removed.
- The top bar (RU, Jarvis, settings) is unchanged.

# OmniNode 5.6 — changelog

- **Top bar restored as in versions before 5.4:** the RU/EN switch, the Jarvis microphone and the settings gear are visible again in the top row under the status bar (next to charge / Wi-Fi indicators).
- Removed the v5.4 workaround where a long press on "OMNINODE" opened settings; the title is a plain label again.
- Camera / AI / reset buttons stay hidden (as before 5.4). The collapsed core overlay still shows only the graph.
- **Language:** Russian is the default again; users previously switched to English by the 5.3 default are moved to Russian once. The RU switch in the top bar is back; it cycles through registered languages only, English stays hidden until `window.OMNI_ALLOW_EN=true` or a new dictionary is added with `I18N.register`.
- **Toggles:** Always On and other switches (`.r16`, `.tg15`, `.sw`): the knob offset was applied twice (`left` + `translateX`) and left the track; fixed and clipped to the track.
- **Agent search:** "найди ИИ в Google" now opens Google with only «ИИ» (also Яндекс and YouTube, «в/на/через …»). Applied to all three command parsers in the page.
- **Apps:** +61 links added to Games, Browser, Work, Tools, AI, Media and Social sections (https links open the installed app or the site). Only missing entries are added; existing ones are kept; missing sections are created.
- **Russian:** the island update card («Доступна версия …», «Позже», «Обновить») is now Russian.
- **Island:** the music card shows the real title and artist (was hard-coded "OmniNode"); the extra split bubble beside the island is removed.
- **Island home card:** only AI chat, flashlight, screenshot, lock and the timer row remain (other actions are still reachable from settings).
- **Jarvis:** compact sizes; the full-screen backdrop blur is removed (it caused white flashes in WebView).

# OmniNode 5.5 — changelog

- **Fixed (critical):** the v5.4 inserts (core-only graph, catalog, corepure) were placed inside the `lock` string of the island script, so the whole Dynamic Island script was a syntax error. The string is restored and the blocks moved to the end of the page.
- Island shapes: capsule / drop (water-drop notch, like budget phones) / dot, with size setting.
- Move the island anywhere (sliders X/Y, drag with finger in the app, or drag over other apps via the native window); position is saved.
- Core and island are separate: `startOverlay` only starts the island; the permission wizard respects your choices; expanding one collapses the other.
- Activities screen (Island → Main → Activities): Compact / Expanded, Enable Activity, Geometry & Sizes (width, height, top offset, radius) and features per activity, reset per activity / all.
- Island look redone after the videos: glass expanded cards with a tint gradient and rim, music card (big cover, thin progress bar with times, round play), stopwatch/timer cards with round blue/red buttons and line icons, 4-bar equalizer, SVG icons in the Activities chips.
- Everything from 5.3 and 5.4 is kept (agent app resolution, model auto-resume, catalog, graph-only core...). The classic music / stopwatch / timer cards stay available: Island → Appearance → «Style from the video» (off = classic).
- Glass Layer: blur, refraction, reflection, rim, shadow, tint, glass on cards / buttons, performance modes.

# OmniNode 5.4 — changelog

- Agent: exact app resolution (MAX no longer opens Telegram/Yandex): known packages first, then exact/whole-word label match; "open X" fast path; open is verified against the foreground package.
- Models 0.5 / 1.5 / 3: auto-resume (6 retries, waits for network), WakeLock + foreground keep-alive while downloading, runtime import fallback, clear WebGPU errors.
- Island: window is anchored to the camera cutout (X and Y); width/height/offset settings drive the native window; wider screen-recorder detection.
- Core: main screen shows only the graph (RU / mic / gear buttons hidden; long-press "OMNINODE" opens settings).
- Catalog: MAX and many more messengers, games (Brawl Stars, Stumble Guys, HSR, ZZZ, Wuthering Waves...) and apps; installed apps launch directly by package.

# OmniNode 5.3 — changelog

## Changed
- **AI works like the previous version again.** Free engines first (Pollinations, Pollinations gen — no download, no key), then on-device Qwen
  (Light 0.5B / Medium 1.5B / Heavy 3B) that downloads directly with the "Download" button in AI settings, then your own API keys.
  The "AI models" manager no longer replaces the download buttons; its button and its node in the AI branch are removed.
- **Dynamic Island → Preview:** the extra "Остров+" block (Face ID, sound, silent, vibration, volume, Wi-Fi, mic, camera) is removed.
  All previews stay in the main list (charging, low battery, silent, vibrate, DND, Wi-Fi, VPN, hotspot, Face ID, lock...).

## Fixed
- Russian mode: Live Activities island texts (Charging, Silent, Vibrate, On/Off, Offline...), the new settings rows, preview buttons,
  startup banner, error/recovery screen and "What's new" are now translated.
- Qwen download card in English mode: the progress card could not detect "Model downloaded" / "Download failed" after the UI text was translated.

## Fixed
- **Black screen "Нарушена целостность приложения" after tapping the core.** Root cause: in the collapsed-core overlay the CSS rule
  `html.core28c body > :not(#g) {display:none!important}` hid the copyright footer `#cr2`; the integrity guard checked it every 4 s,
  treated "hidden" as tampering and replaced the whole page. The footer and the self-destructing check are gone. Copyright stays in the
  file header, the console banner and About → What's new.
- Fake status removed: the startup banner "Qwen готов" was shown even with no model loaded. It now reflects the real state.
- Old "Remove model" only cleared a flag and left the files on the device. Models are now deleted from the cache for real.
- Silent model download over mobile data / Data Saver at startup is now blocked.
- Graph nodes overlapping each other (11–20 touching pairs on common phone sizes → 0 on 360×780, 390×844, 412×915, 320×568, 800×1280).

## Added
- Dynamic Island **Live Activities look** (Island → Appearance → "Live Activities look"): tinted outline + glow per activity, animated icons,
  call / timer / stopwatch / recording / music / navigation / charging / low battery / headphones / silent·vibrate / Wi-Fi / Do Not Disturb /
  VPN / hotspot / Face ID scan → unlock. New previews in Island → Preview.
- **AI models manager** (AI branch → "AI models", or AI settings → "On-device models"): AI Model 0.5 / 1.5 / 3 (Qwen2.5 q4f16_1 via WebLLM).
  Device check (WebGPU, RAM, free storage, network), real progress, cancel, cache verification, activate with self-test, release memory, delete.
  Model sources are configurable: `window.OMNI_MODELS_CONFIG` / `__m29.register()`.
- Download progress is shown in the island.
- Error boundary + recovery screen (Reload / Reset graph layout) instead of a blank screen; log in `localStorage.omni29err`.
- i18n engine (`window.I18N`): English is the default; RU stays available; more languages via `I18N.register(lang, dict)`.
  Dictionary source: `docs/i18n_en.json` (1 212 entries). `I18N.missing()` lists untranslated text at runtime.
- Speech recognition / TTS language follows the UI language.

## Known limits
- The voice/text agent understands **Russian commands only** (`открой`, `запусти`, `включи`…). Example commands are therefore kept in Russian.
- Real triggers for DND / VPN / hotspot pills need native emitters (`OmniIsland.sys('dnd'|'vpn'|'hotspot', …)`); previews work now.
- Long-tail Russian strings (mostly the agent's example commands and brand monograms) remain.
- Model downloads were tested against a simulated WebLLM module; a real download needs a device with WebGPU and network.
