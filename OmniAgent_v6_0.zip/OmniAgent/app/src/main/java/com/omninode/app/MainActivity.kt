package com.omninode.app
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView

class MainActivity : Activity() {
    companion object { @Volatile var inst: MainActivity? = null }
    private lateinit var web: WebView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        inst = this
        Speaker.init(this)
        if (!Prefs.b(this, "perm_asked")) { Prefs.set(this, "perm_asked", true); requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_CONTACTS, Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.CAMERA), 1) }
        web = WebView(this)
        WebSetup.setup(web, this)
        OverlayService.webs.add(web)
        setContentView(web)
        Modes.apply(this)
        Jobs.restore(this)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }
    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); setIntent(i) }
    override fun onStart() { super.onStart(); OverlayService.appFg = true; OverlayService.inst?.applyModes() }
    override fun onStop() { OverlayService.appFg = false; try { web.evaluateJavascript("window.__qwBusy&&Android.keepAlive(true)", null) } catch (e: Exception) {}; OverlayService.inst?.applyModes(); super.onStop() }
    override fun onDestroy() { OverlayService.webs.remove(web); if (inst === this) inst = null; super.onDestroy() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else moveTaskToBack(true) }
}
