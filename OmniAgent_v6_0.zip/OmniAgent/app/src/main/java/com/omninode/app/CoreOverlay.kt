package com.omninode.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.webkit.WebView
import android.widget.FrameLayout

/** Нарисованное ядро: лёгкий нативный виджет (без WebView), пока меню свёрнуто. */
class OrbView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var accent: Int = Color.parseColor("#7AA2FF")
        set(v) { field = v; invalidate() }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var angle = 0f
    private var pulse = 1f
    private var an: ValueAnimator? = null

    private fun a(c: Int, al: Int) = Color.argb(al, Color.red(c), Color.green(c), Color.blue(c))

    override fun onAttachedToWindow() { super.onAttachedToWindow(); start() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, vis: Int) { super.onVisibilityChanged(v, vis); if (vis == VISIBLE && isAttachedToWindow) start() else stop() }

    private fun start() {
        if (an != null) return
        val x = ValueAnimator.ofFloat(0f, 1f)
        x.duration = 14000; x.repeatCount = ValueAnimator.INFINITE; x.interpolator = android.view.animation.LinearInterpolator()
        x.addUpdateListener { v ->
            val f = v.animatedValue as Float
            angle = f * 360f
            pulse = 1f + 0.035f * Math.sin(f * 14000 / 3000 * 2 * Math.PI).toFloat()
            invalidate()
        }
        an = x; x.start()
    }
    private fun stop() { an?.cancel(); an = null }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = 29f * d * pulse
        glow.shader = RadialGradient(cx, cy, r * 1.9f, intArrayOf(a(accent, 90), a(accent, 0)), floatArrayOf(0.3f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.9f, glow)
        body.shader = RadialGradient(cx, cy, r, intArrayOf(Color.WHITE, a(accent, 82), a(accent, 15)), floatArrayOf(0.09f, 0.1f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, body)
        edge.strokeWidth = 1.2f * d; edge.color = accent
        c.drawCircle(cx, cy, r, edge)
        ring.strokeWidth = 1f * d; ring.color = a(accent, 150)
        ring.pathEffect = DashPathEffect(floatArrayOf(4f * d, 4f * d), 0f)
        c.save(); c.rotate(angle, cx, cy); c.drawCircle(cx, cy, r + 8f * d, ring); c.restore()
        c.drawCircle(cx, cy, 5f * d, dot)
    }
}

class CoreOverlay(private val svc: OverlayService, private val ctx: Context, private val wm: WindowManager) {
    private val OV = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    private val dm = ctx.resources.displayMetrics
    private fun dp(v: Int) = (v * dm.density).toInt()
    private val pr = Prefs.sp(ctx)
    private var orb: OrbView? = null
    private var orbLp: WindowManager.LayoutParams? = null
    private var root: FrameLayout? = null
    private var web: WebView? = null
    private var rootLp: WindowManager.LayoutParams? = null
    var expanded = false
        private set
    private val size get() = dp(104)

    private fun statusH(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    fun setColor(hex: String) { try { orb?.accent = Color.parseColor(hex) } catch (e: Exception) {} }

    fun showOrb() {
        if (orb != null) return
        val v = OrbView(ctx)
        try { v.accent = Color.parseColor(pr.getString("core_color", "#7aa2ff")) } catch (e: Exception) {}
        val lp = WindowManager.LayoutParams(size, size, OV,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = pr.getInt("core_x", dm.widthPixels - size + dp(10)); lp.y = pr.getInt("core_y", (dm.heightPixels * 0.4).toInt())
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > slop || Math.abs(e.rawY - sy) > slop) moved = true
                    if (moved) {
                        lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) expand() else snap(v, lp)
            }
            true
        }
        try { wm.addView(v, lp); orb = v; orbLp = lp } catch (e: Exception) {}
    }

    private fun snap(v: View, lp: WindowManager.LayoutParams) {
        val mid = lp.x + size / 2
        val tx = if (mid < dm.widthPixels / 2) -dp(10) else dm.widthPixels - size + dp(10)
        val ty = lp.y.coerceIn(statusH(), dm.heightPixels - size - dp(40))
        val x0 = lp.x; val y0 = lp.y
        val a = ValueAnimator.ofFloat(0f, 1f); a.duration = 180; a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { an ->
            val f = an.animatedValue as Float
            lp.x = (x0 + (tx - x0) * f).toInt(); lp.y = (y0 + (ty - y0) * f).toInt()
            try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        }
        a.start()
        pr.edit().putInt("core_x", tx).putInt("core_y", ty).apply()
    }

    private fun ensurePanel() {
        if (root != null) return
        val c = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault)
        val r = object : FrameLayout(c) {
            override fun dispatchKeyEvent(e: KeyEvent): Boolean {
                if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (e.action == KeyEvent.ACTION_UP) web?.evaluateJavascript("window.__core28&&__core28('back')", null)
                    return true
                }
                return super.dispatchKeyEvent(e)
            }
        }
        r.setBackgroundColor(Color.argb(0xE6, 6, 8, 18))
        val w = WebView(c)
        WebSetup.setup(w, ctx) { collapse() }
        w.setBackgroundColor(Color.TRANSPARENT)
        w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        OverlayService.webs.add(w)
        r.addView(w, FrameLayout.LayoutParams(-1, -1).apply { topMargin = statusH() })
        val lp = WindowManager.LayoutParams(1, 1, OV,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        r.visibility = View.GONE
        try { wm.addView(r, lp) } catch (e: Exception) { OverlayService.webs.remove(w); w.destroy(); return }
        root = r; web = w; rootLp = lp
        w.loadUrl("https://appassets.androidplatform.net/assets/index.html#overlay")
    }

    private var lastToggle = 0L
    fun expand() {
        if (expanded) return
        val now = System.currentTimeMillis()
        if (now - lastToggle < 350) return
        lastToggle = now; svc.coreOpenedAt = now
        OverlayService.emit("try{window.OmniIsland&&OmniIsland.close&&OmniIsland.close()}catch(e){}")
        ensurePanel()
        val r = root ?: return; val lp = rootLp ?: return; val w = web ?: return
        expanded = true
        try { w.onResume() } catch (e: Exception) {}
        lp.width = WindowManager.LayoutParams.MATCH_PARENT; lp.height = WindowManager.LayoutParams.MATCH_PARENT
        lp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        try { wm.updateViewLayout(r, lp) } catch (e: Exception) {}
        val ol = orbLp
        r.pivotX = ((ol?.x ?: dm.widthPixels / 2) + size / 2).toFloat(); r.pivotY = ((ol?.y ?: dm.heightPixels / 2) + size / 2).toFloat()
        r.visibility = View.VISIBLE
        r.alpha = 0f; r.scaleX = 0.86f; r.scaleY = 0.86f
        r.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()
        orb?.visibility = View.INVISIBLE
        r.requestFocus()
        w.evaluateJavascript("window.__core28&&__core28('expand')", null)
    }

    fun collapse() {
        if (!expanded) return
        val now = System.currentTimeMillis()
        if (now - lastToggle < 250) return
        lastToggle = now
        val r = root ?: return; val lp = rootLp ?: return
        expanded = false
        r.animate().alpha(0f).scaleX(0.86f).scaleY(0.86f).setDuration(160).withEndAction {
            if (expanded) return@withEndAction
            r.visibility = View.GONE
            lp.width = 1; lp.height = 1
            lp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
            try { wm.updateViewLayout(r, lp) } catch (e: Exception) {}
            web?.evaluateJavascript("window.__core28&&__core28('collapsed')", null)
            try { web?.onPause() } catch (e: Exception) {}
        }.start()
        orb?.visibility = View.VISIBLE
    }

    fun hideOrb() {
        if (expanded) { expanded = false; root?.let { it.visibility = View.GONE; rootLp?.let { lp -> lp.width = 1; lp.height = 1; lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; try { wm.updateViewLayout(it, lp) } catch (e: Exception) {} } } }
        orb?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        orb = null; orbLp = null
    }

    fun shown() = orb != null

    fun detach() {
        hideOrb()
        root?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        web?.let { OverlayService.webs.remove(it); try { it.destroy() } catch (e: Exception) {} }
        root = null; web = null; rootLp = null
    }
}
