package com.omninode.app
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

class OverlayService : Service() {
    companion object {
        var inst: OverlayService? = null
        @Volatile var appFg = false
        val webs: MutableSet<WebView> = java.util.Collections.synchronizedSet(mutableSetOf<WebView>())
        /** Выполнить JS во всех окнах OmniNode (основное, ядро, остров). */
        fun emit(code: String) {
            synchronized(webs) { webs.toList() }.forEach { w -> w.post { try { w.evaluateJavascript(code, null) } catch (e: Exception) {} } }
        }
    }
    private var inited = false
    private var gameFg = false
    private lateinit var wm: WindowManager
    private var core: CoreOverlay? = null
    private var island: IslandOverlay? = null
    private var mediaReady = false
    private var lastTry = 0L
    private var lastNum = ""
    private var wasRinging = false
    private var answered = false
    private val h = Handler(Looper.getMainLooper())
    private val ticker: Runnable = object : Runnable {
        override fun run() {
            if (!mediaReady) { if (System.currentTimeMillis() - lastTry > 4000) { lastTry = System.currentTimeMillis(); setupMedia() }; h.postDelayed(this, 4000) }
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val OV = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    /** Выполнить JS в острове (и в окне приложения): будим остров, если он спит. */
    private fun isl(js: String) { h.post { island?.wake(); emit("try{" + js + "}catch(e){}") } }
    private fun q(s: String) = JSONObject.quote(s)

    // ---------- события → остров ----------
    private var lastAgent = ""; private var lastAgentAt = 0L
    fun setIsland(t: String) { h.post {
        val n = System.currentTimeMillis()
        if (t == lastAgent && n - lastAgentAt < 1500) return@post
        lastAgent = t; lastAgentAt = n
        isl("OmniIsland.push('🤖'," + q(t.take(60)) + ",3500,'sys')")
    } }
    private val replies = HashMap<String, android.app.Notification.Action>()
    private val intents = HashMap<String, PendingIntent>()
    private var navPi: PendingIntent? = null
    private var navClear: Runnable? = null
    private var progClear: Runnable? = null
    fun onNotif(title: String, text: String, pi: PendingIntent?, pkg: String = "", reply: android.app.Notification.Action? = null) { h.post {
        if (pkg.isNotEmpty()) { if (reply != null) replies[pkg] = reply else replies.remove(pkg); if (pi != null) intents[pkg] = pi }
        val pay = Regex("(?i)(списан|оплат|покупк|перевод|поступил|\\u20bd|руб|payment|paid)").containsMatchIn(title + " " + text)
        if (pay) {
            val am = Regex("(\\d[\\d\\s.,]*)\\s*(\\u20bd|руб)").find(title + " " + text)?.value ?: title
            isl("OmniIsland.paid({amount:" + q(am.trim()) + "})")
        } else {
            val app = if (pkg.isNotEmpty()) Apps.label(this, pkg) else ""
            isl("OmniIsland.notify({app:" + q(app) + ",title:" + q(title) + ",text:" + q(text) + ",key:" + q(pkg) + "})")
        }
    } }
    fun sendReply(key: String, text: String) {
        val a = replies[key] ?: return
        try {
            val ri = a.remoteInputs[0]; val i = Intent(); val b = android.os.Bundle()
            b.putCharSequence(ri.resultKey, text)
            android.app.RemoteInput.addResultsToIntent(a.remoteInputs, i, b)
            a.actionIntent.send(this, 0, i)
        } catch (e: Exception) {}
    }
    fun startTimer(sec: Int, label: String) { isl("OmniIsland.timer(" + sec + "," + q(label.ifBlank { "Таймер" }) + ")") }
    fun stopwatch(cmd: String) { isl("OmniIsland.kact(" + q(if (cmd == "start") "sw" else if (cmd == "toggle") "swp" else "swr") + ")") }
    fun refreshIsland() { island?.reload() }
    fun onTrack(icon: String, title: String, text: String, kind: String) { h.post {
        if (kind == "taxi") isl("OmniIsland.nav({kind:'ride',title:" + q(title) + ",eta:" + q(text) + ",plate:'',pct:0})")
        else isl("OmniIsland.nav({arrow:'straight',dist:" + q(title) + ",street:" + q(text) + ",eta:'',min:'',km:''})")
        navClear?.let { h.removeCallbacks(it) }
        val r = Runnable { isl("OmniIsland.nav(null)") }; navClear = r; h.postDelayed(r, 60000)
    } }
    fun navOpen() { try { navPi?.send() } catch (e: Exception) {} }
    fun onProgress(icon: String, label: String, title: String, pct: Int) { h.post {
        isl("OmniIsland.progress({title:" + q(label + " · " + title) + ",pct:" + pct + "})")
        progClear?.let { h.removeCallbacks(it) }
        val r = Runnable { isl("OmniIsland.progress(null)") }; progClear = r; h.postDelayed(r, if (pct >= 100) 2500 else 20000)
    } }
    fun onRec(on: Boolean) { isl(if (on) "OmniIsland.rec({on:1})" else "OmniIsland.rec(null)") }
    fun orb(text: String) {}  // «магический шар» удалён
    fun onCallRec(on: Boolean) { isl("OmniIsland.callRec(" + on + ")") }

    // ---------- звонки ----------
    fun onCall(state: String, number: String?) { h.post {
        if (!number.isNullOrBlank()) lastNum = number
        val name = if (lastNum.isNotBlank()) (lookup(lastNum) ?: lastNum) else "Звонок"
        when (state) {
            "RINGING" -> { wasRinging = true; answered = false; isl("OmniIsland.call({name:" + q(name) + ",state:'incoming'})") }
            "OFFHOOK" -> { answered = true; isl("OmniIsland.call({name:" + q(name) + ",state:" + (if (wasRinging) "'active'" else "'out'") + "})") }
            else -> {
                if (wasRinging && !answered) isl("OmniIsland.call({name:" + q(name) + ",state:'missed'})")
                else isl("OmniIsland.call({state:'end'})")
                wasRinging = false; answered = false; lastNum = ""
            }
        }
    } }
    private fun lookup(num: String): String? {
        return try {
            val u = android.net.Uri.withAppendedPath(android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI, android.net.Uri.encode(num))
            contentResolver.query(u, arrayOf(android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    // ---------- звонящий таймер ----------
    private var ringtone: android.media.Ringtone? = null
    fun ringOn() { h.post {
        if (ringtone != null) return@post
        try { (getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator).vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400, 200, 400), -1)) } catch (e: Exception) {}
        try { val rt = android.media.RingtoneManager.getRingtone(this, android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM)); ringtone = rt; rt.play(); h.postDelayed({ ringOff(false) }, 30000) } catch (e: Exception) {}
    } }
    fun ringOff(sync: Boolean = true) { h.post {
        val rt = ringtone ?: return@post
        try { rt.stop() } catch (e: Exception) {}
        ringtone = null
        if (sync) emit("try{OmniIsland.kact('rx')}catch(e){}")
    } }
    private var lastTimerMsg = ""; private var lastTimerAt = 0L
    fun syncTimer(sec: Int, label: String) { h.post {
        val k = "$sec:$label"; val n = System.currentTimeMillis()
        if (k == lastTimerMsg && n - lastTimerAt < 800) return@post
        lastTimerMsg = k; lastTimerAt = n
        startTimer(sec, label)
    } }

    // ---------- системные события ----------
    private fun nfcState(): String = try { val a = android.nfc.NfcAdapter.getDefaultAdapter(this); if (a == null) "нет" else if (a.isEnabled) "вкл" else "выкл" } catch (e: Exception) { "?" }
    fun demo(kind: String) { h.post {
        val m = mapOf("ring" to "call_in", "talk" to "call_on", "payw" to "pay", "paid" to "paid", "msg" to "msg", "pomo" to "tm", "sw" to "sw", "alarm" to "ring",
            "charge" to "chg", "low" to "bat", "phones" to "hp", "phbat" to "btp", "nav" to "nav", "taxi" to "ride", "rec" to "rec", "dl" to "prg", "upd" to "upd",
            "plane" to "air", "paydiag" to "diag")
        val k = m[kind]
        when {
            k != null -> isl("OmniIsland.demo(" + q(k) + ")")
            kind == "faceok" -> isl("OmniIsland.faceid(true)")
            kind == "facefail" -> isl("OmniIsland.faceid(false)")
            kind == "silent" -> isl("OmniIsland.ringer('silent')")
            kind == "sound" -> isl("OmniIsland.ringer('ring')")
            kind == "vibr" -> isl("OmniIsland.ringer('vibrate')")
            kind == "volume" -> isl("OmniIsland.volume(60)")
            kind == "wifi" -> isl("OmniIsland.wifi('Домашняя сеть')")
            kind == "mic" -> { micOn = true; updateDots(); h.postDelayed({ micOn = false; updateDots() }, 4000) }
            kind == "cam" -> { camOn = true; updateDots(); h.postDelayed({ camOn = false; updateDots() }, 4000) }
        }
    } }
    private var micOn = false; private var camOn = false; private val camBusy = HashSet<String>()
    private var dotsView: LinearLayout? = null; private var micDot: TextView? = null; private var camDot: TextView? = null
    private fun updateDots() { h.post {
        val m = micDot; val c = camDot; val d = dotsView ?: return@post
        m?.visibility = if (micOn) View.VISIBLE else View.GONE
        c?.visibility = if (camOn || camBusy.isNotEmpty()) View.VISIBLE else View.GONE
        d.visibility = if (!appFg && (micOn || camOn || camBusy.isNotEmpty())) View.VISIBLE else View.GONE
    } }
    private fun statusH(): Int { val id = resources.getIdentifier("status_bar_height", "dimen", "android"); return if (id > 0) resources.getDimensionPixelSize(id) else dp(24) }
    private fun registerPrivacy() {
        val ll = LinearLayout(this); ll.orientation = LinearLayout.HORIZONTAL
        fun dot(c: String): TextView { val t = TextView(this); t.text = "●"; t.textSize = 9f; t.setTextColor(Color.parseColor(c)); t.setPadding(dp(2), 0, dp(2), 0); t.visibility = View.GONE; ll.addView(t); return t }
        micDot = dot("#FF9500"); camDot = dot("#30D158")
        ll.visibility = View.GONE
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, OV,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; lp.x = dp(78); lp.y = statusH() + dp(22)
        if (android.os.Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(ll, lp); dotsView = ll } catch (e: Exception) {}
        try {
            (getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).registerAudioRecordingCallback(object : android.media.AudioManager.AudioRecordingCallback() {
                override fun onRecordingConfigChanged(configs: MutableList<android.media.AudioRecordingConfiguration>?) { micOn = !configs.isNullOrEmpty(); updateDots() }
            }, h)
        } catch (e: Exception) {}
        try {
            (getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager).registerAvailabilityCallback(object : android.hardware.camera2.CameraManager.AvailabilityCallback() {
                override fun onCameraUnavailable(id: String) { camBusy.add(id); updateDots() }
                override fun onCameraAvailable(id: String) { camBusy.remove(id); updateDots() }
            }, h)
        } catch (e: Exception) {}
    }
    private var evUp = 0L
    private var lastPct = -1
    private fun ev(js: String) {
        if (System.currentTimeMillis() - evUp < 3500) return
        isl(js)
    }
    private fun registerEvents() {
        evUp = System.currentTimeMillis()
        val f = android.content.IntentFilter().apply {
            addAction(android.media.AudioManager.RINGER_MODE_CHANGED_ACTION); addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED); addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED); addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(android.media.AudioManager.ACTION_HEADSET_PLUG); addAction("android.media.VOLUME_CHANGED_ACTION"); addAction("android.bluetooth.device.action.BATTERY_LEVEL_CHANGED")
        }
        val r = object : android.content.BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                when (i.action) {
                    android.media.AudioManager.RINGER_MODE_CHANGED_ACTION -> when ((getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).ringerMode) {
                        android.media.AudioManager.RINGER_MODE_SILENT -> ev("OmniIsland.ringer('silent')")
                        android.media.AudioManager.RINGER_MODE_VIBRATE -> ev("OmniIsland.ringer('vibrate')")
                        else -> ev("OmniIsland.ringer('ring')")
                    }
                    Intent.ACTION_POWER_CONNECTED -> ev("OmniIsland.sys('charge',{on:true,pct:" + lastPct + "})")
                    Intent.ACTION_POWER_DISCONNECTED -> ev("OmniIsland.sys('charge',{on:false})")
                    Intent.ACTION_BATTERY_CHANGED -> {
                        val l = i.getIntExtra("level", -1); val sc = i.getIntExtra("scale", 100)
                        val pct = if (l >= 0 && sc > 0) l * 100 / sc else -1
                        val ch = i.getIntExtra("plugged", 0) != 0
                        if (lastPct >= 0 && pct != lastPct) {
                            if (!ch && pct in intArrayOf(20, 10, 5)) ev("OmniIsland.push('🪫','Заряд $pct%',3500,'lo','Пора на зарядку',$pct)")
                            if (ch && pct == 100) ev("OmniIsland.push('✅','Заряжено полностью',3000,'ch',null,100)")
                        }
                        lastPct = pct
                    }
                    Intent.ACTION_USER_PRESENT -> ev("OmniIsland.faceid(true)")
                    Intent.ACTION_AIRPLANE_MODE_CHANGED -> ev("OmniIsland.sys('airplane',{on:" + i.getBooleanExtra("state", false) + "})")
                    android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED -> {
                        val n = try { (i.getParcelableExtra<android.bluetooth.BluetoothDevice>(android.bluetooth.BluetoothDevice.EXTRA_DEVICE))?.name } catch (e: Exception) { null }
                        ev("OmniIsland.sys('bt',{on:true,name:" + q(n ?: "Bluetooth") + "})")
                    }
                    android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED -> ev("OmniIsland.sys('bt',{on:false,name:'Bluetooth'})")
                    "android.media.VOLUME_CHANGED_ACTION" -> if (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) == 3) {
                        val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", 0); val mx = (getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).getStreamMaxVolume(3)
                        ev("OmniIsland.volume(" + (if (mx > 0) v * 100 / mx else 0) + ")")
                    }
                    "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED" -> { val lv = i.getIntExtra("android.bluetooth.device.extra.BATTERY_LEVEL", -1); if (lv >= 0) ev("OmniIsland.push('🎧','Наушники',3000,'hp','Заряд $lv%',$lv)") }
                    android.media.AudioManager.ACTION_HEADSET_PLUG -> ev("OmniIsland.push('🎧'," + q(if (i.getIntExtra("state", 0) == 1) "Наушники подключены" else "Наушники отключены") + ",0,'hp')")
                }
            }
        }
        androidx.core.content.ContextCompat.registerReceiver(this, r, f, androidx.core.content.ContextCompat.RECEIVER_EXPORTED)
        evRecv = r
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val cb = object : android.net.ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: android.net.Network) { ev("OmniIsland.sys('wifi',{on:true})") }
                override fun onLost(n: android.net.Network) { ev("OmniIsland.sys('wifi',{on:false})") }
            }
            cm.registerNetworkCallback(android.net.NetworkRequest.Builder().addTransportType(android.net.NetworkCapabilities.TRANSPORT_WIFI).build(), cb)
            netCb = cb
        } catch (e: Exception) {}
    }
    private var evRecv: android.content.BroadcastReceiver? = null
    private var netCb: android.net.ConnectivityManager.NetworkCallback? = null

    // ---------- музыка ----------
    private var ctrl: android.media.session.MediaController? = null
    private var mcb: android.media.session.MediaController.Callback? = null
    private var lastTitle = ""
    private fun setupMedia() {
        try {
            val cn = android.content.ComponentName(this, OmniNotifService::class.java)
            val m = getSystemService(Context.MEDIA_SESSION_SERVICE) as android.media.session.MediaSessionManager
            m.addOnActiveSessionsChangedListener({ list -> pickSession(list) }, cn)
            pickSession(m.getActiveSessions(cn)); mediaReady = true
        } catch (e: SecurityException) {} catch (e: Exception) {}
    }
    private fun pickSession(list: List<android.media.session.MediaController>?) {
        val c = list?.firstOrNull { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        h.post { bindController(c) }
    }
    private fun bindController(c: android.media.session.MediaController?) {
        if (c != null && ctrl != null && c.sessionToken == ctrl?.sessionToken) return
        try { mcb?.let { ctrl?.unregisterCallback(it) } } catch (e: Exception) {}
        mcb = null; ctrl = c
        if (c == null) { lastTitle = ""; isl("OmniIsland.media(null)"); return }
        val cb = object : android.media.session.MediaController.Callback() {
            override fun onMetadataChanged(md: android.media.MediaMetadata?) { pushMedia(true) }
            override fun onPlaybackStateChanged(st: android.media.session.PlaybackState?) { pushMedia(false) }
            override fun onSessionDestroyed() { bindController(null) }
        }
        mcb = cb; c.registerCallback(cb, h)
        pushMedia(true)
    }
    private fun pushMedia(meta: Boolean) {
        val c = ctrl ?: return
        val md = c.metadata
        val t = md?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: ""
        if (t.isEmpty()) { isl("OmniIsland.media(null)"); return }
        val a = md?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val st = c.playbackState
        val playing = st?.state == android.media.session.PlaybackState.STATE_PLAYING
        val pos = (st?.position ?: 0L) / 1000
        val dur = (md?.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION) ?: 0L) / 1000
        var cover = ""
        if (t != lastTitle || meta) {
            val b = md?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART)
            if (b != null) {
                try {
                    val sm = android.graphics.Bitmap.createScaledBitmap(b, 96, 96, true)
                    val bo = java.io.ByteArrayOutputStream(); sm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 72, bo)
                    cover = "data:image/jpeg;base64," + android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
                } catch (e: Exception) {}
            }
        }
        lastTitle = t
        isl("OmniIsland.media({title:" + q(t) + ",artist:" + q(a) + ",playing:" + playing + ",pos:" + pos + ",dur:" + dur + (if (cover.isNotEmpty()) ",cover:" + q(cover) else "") + "})")
    }

    fun stopAgents() {
        NativeAgent.stop()
        synchronized(webs) { webs.toList() }.forEach { w -> w.post { w.evaluateJavascript("window.__stop23&&window.__stop23()", null) } }
    }
    private fun txt(t: String, size: Float = 16f): TextView {
        val v = TextView(this); v.text = t; v.textSize = size; v.setTextColor(Color.WHITE)
        v.gravity = Gravity.CENTER; v.setPadding(dp(10), dp(6), dp(10), dp(6)); return v
    }

    // ---------- ядро ----------
    private var islExpanded = false
    @Volatile var coreOpenedAt = 0L
    fun coreShown(): Boolean = core?.shown() == true
    fun islandShown(): Boolean = island != null
    fun showPanel(show: Boolean) { h.post { if (show) { if (core == null) return@post; emit("try{window.OmniIsland&&OmniIsland.close&&OmniIsland.close()}catch(e){}"); core?.expand() } else core?.collapse() } }
    fun coreCollapse() { h.post { core?.collapse() } }
    fun setCoreColor(hex: String) { Prefs.sp(this).edit().putString("core_color", hex).apply(); h.post { core?.setColor(hex) } }
    fun islandWin(m: String) { h.post {
        island?.resize(m)
        // раскрытие острова сворачивает ядро только в момент перехода (а не на каждое обновление размера)
        val ex = m.split(",").getOrNull(3)?.trim() == "1"
        if (ex && !islExpanded && System.currentTimeMillis() - coreOpenedAt > 1500) core?.collapse()
        islExpanded = ex
    } }
    fun islandPos(m: String) { h.post { island?.setPos(m) } }
    fun islandMove(on: Boolean) { h.post { if (on) island?.beginMove() else island?.endMove() } }
    fun islandCutout(): String = island?.cutoutDp() ?: "0,0,0"
    fun islandFocus(on: Boolean) { h.post { island?.setFocusable(on) } }
    fun islandReload() { h.post { island?.reload() } }

    /** Применяет переключатели: показывает/убирает ядро и остров, при необходимости останавливает службу. */
    private var applyPending = false
    /** Склеивает частые вызовы (смена окна, агент, игры) в один проход: ядро и остров больше не «моргают». */
    fun applyModes() {
        if (applyPending) return
        applyPending = true
        h.postDelayed({ applyPending = false; applyModesNow() }, 180)
    }
    private fun applyModesNow() {
        h.post {
            if (!inited) return@post
            val coreOn = Prefs.b(this, "core_on")
            val islOn = Prefs.b(this, "island_on")
            val hide = Prefs.b(this, "hide_games", true) && gameFg
            if (coreOn) { if (core == null) core = CoreOverlay(this, this, wm) }
            val c = core
            if (c != null) { if (coreOn && !hide && !appFg) c.showOrb() else { c.hideOrb() } ; if (!coreOn) { c.detach(); core = null } }
            if (islOn) { if (island == null) { val i = IslandOverlay(this, wm); i.attach(); island = i }; island?.hiddenByApp = appFg }
            else { island?.detach(); island = null }
            dotsView?.let { updateDots() }
            if (!coreOn && !islOn && !Prefs.b(this, "bg_on") && !NativeAgent.isRunning && Jobs.pending(this) == 0) stopSelf()
        }
    }

    private fun isGame(pkg: String): Boolean {
        try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            if (ai.category == android.content.pm.ApplicationInfo.CATEGORY_GAME) return true
        } catch (e: Exception) {}
        val l = pkg.lowercase()
        return listOf("supercell", "mojang", "roblox", "tencent", "activision", "mihoyo", "garena", "dts.freefire", "axlebolt",
            "innersloth", "kiloo", "wargaming", "epicgames", "king.candycrush", "rovio", "gameloft", "netease", "miniclip").any { l.contains(it) }
    }

    /** Вызывается службой доступности при смене приложения на переднем плане. */
    fun onForeground(pkg: String) {
        h.post {
            val g = isGame(pkg)
            if (g != gameFg) { gameFg = g; applyModes() }
        }
    }

    /** Нативное окно подтверждения поверх любых приложений (оплаты, пароли). */
    fun confirm(title: String, msg: String, yes: String, no: String, cb: (Boolean) -> Unit) {
        h.post {
            if (!inited) { cb(false); return@post }
            val c = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
            val card = LinearLayout(c); card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(20), dp(18), dp(20), dp(14))
            card.background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(Color.parseColor("#F2121428")); setStroke(dp(2), Color.parseColor("#AAFFB347")) }
            val tt = txt(title, 17f); tt.gravity = Gravity.START; tt.setTypeface(null, Typeface.BOLD)
            val mm = txt(msg, 14f); mm.gravity = Gravity.START
            card.addView(tt); card.addView(mm)
            val row = LinearLayout(c); row.orientation = LinearLayout.HORIZONTAL; row.setPadding(0, dp(10), 0, 0)
            var done = false
            fun end(ok: Boolean) {
                if (done) return
                done = true
                try { wm.removeView(card) } catch (e: Exception) {}
                cb(ok)
            }
            fun button(label: String, col: String, ok: Boolean): TextView {
                val b = txt(label, 15f); b.setTypeface(null, Typeface.BOLD)
                b.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.parseColor(col)) }
                b.setOnClickListener { end(ok) }
                return b
            }
            val lpb = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); lpb.setMargins(dp(4), 0, dp(4), 0)
            row.addView(button(no, "#E5484D", false), lpb)
            row.addView(button(yes, "#30A46C", true), lpb)
            card.addView(row)
            val lp = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * 0.9).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, OV,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
            lp.gravity = Gravity.CENTER
            try { wm.addView(card, lp) } catch (e: Exception) { cb(false); return@post }
            h.postDelayed({ end(false) }, 120000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("omni", "OmniNode", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "omni").setContentTitle("OmniNode работает").setSmallIcon(android.R.drawable.ic_menu_compass).build())
        inst = this
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (!inited) {
            inited = true
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            Speaker.init(this)
            registerEvents()
            registerPrivacy()
            h.post(ticker)
            Jobs.restore(this)
        }
        applyModes()
        return START_STICKY
    }
    override fun onDestroy() {
        try {
            core?.detach(); island?.detach()
            dotsView?.let { wm.removeView(it) }
            evRecv?.let { unregisterReceiver(it) }
            netCb?.let { (getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager).unregisterNetworkCallback(it) }
            try { mcb?.let { ctrl?.unregisterCallback(it) } } catch (e: Exception) {}
        } catch (e: Exception) {}
        h.removeCallbacks(ticker)
        ringtone?.let { try { it.stop() } catch (e: Exception) {} }
        core = null; island = null; inst = null; super.onDestroy()
    }
}
