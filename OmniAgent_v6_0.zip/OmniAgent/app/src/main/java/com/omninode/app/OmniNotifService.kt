package com.omninode.app
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class OmniNotifService : NotificationListenerService() {
    companion object {
        private val recent = ArrayList<String>()
        fun remember(s: String) { synchronized(recent) { recent.add(s); while (recent.size > 40) recent.removeAt(0) } }
        fun digest(): String = synchronized(recent) { recent.takeLast(25).joinToString("\n") }
    }
    private val nav = listOf("yandexnavi", "yandexmaps", "apps.maps", "2gis", "waze", "sygic")
    private val taxi = listOf("yandex.taxi", "ubercab", "mtakso", "citymobil", "taxsee", "maxim")
    private val rec = listOf("smartcapture", "screenrecord", "screenrec", "screen.recorder", "screencap", "hecorat", "mobizen", "xrecorder", "inshot.screenrecorder", "kimcy929", "duapps.recorder", "miui.screenrecorder", "oplus.screenrecorder", "coloros.screenrecorder", "vivo.screenrecorder", "huawei.screenrecorder")
    private fun isRecText(all: String) = Regex("(?i)(запис[а-яё]* экрана|screen record|screen capture|recording screen|идёт запись экрана|screen is being recorded)").containsMatchIn(all)
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val pkg = sbn.packageName
            if (pkg == packageName) return
            val n = sbn.notification; val ex = n.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            if (title.isNotBlank() && (n.flags and Notification.FLAG_GROUP_SUMMARY) == 0 && (n.flags and Notification.FLAG_ONGOING_EVENT) == 0) remember(Apps.label(this, pkg) + ": " + title + (if (text.isNotBlank()) " — " + text else ""))
            val svc = OverlayService.inst ?: return
            val all = title + " " + text
            val dialer = pkg.contains("dialer") || pkg.contains("incallui") || pkg.contains("telecom") || pkg.contains("contacts") || pkg.contains("phone")
            if (dialer && (all.contains("запис", true) || all.contains("record", true))) { svc.onCallRec(true); return }
            if (rec.any { pkg.contains(it) } || ((pkg.contains("systemui") || pkg.contains("android.system")) && isRecText(all))) { svc.onRec(true); return }
            if (nav.any { pkg.contains(it) }) { if (title.isNotBlank()) svc.onTrack("🧭", title, text, "nav"); return }
            if (taxi.any { pkg.contains(it) }) { if (title.isNotBlank()) svc.onTrack("🚕", title, text, "taxi"); return }
            val pmax = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0); val prog = ex.getInt(Notification.EXTRA_PROGRESS, 0)
            if (pmax > 0 && !ex.getBoolean(Notification.EXTRA_PROGRESS_INDETERMINATE, false)) {
                val up = pkg == "com.android.vending"
                svc.onProgress(if (up) "⬆" else "⬇", if (up) "Обновление" else "Загрузка", title, prog * 100 / pmax); return
            }
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0 || (n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
            if (n.category == Notification.CATEGORY_TRANSPORT || n.category == Notification.CATEGORY_CALL || n.category == Notification.CATEGORY_PROGRESS) return
            if (title.isBlank()) return
            val reply = n.actions?.firstOrNull { a -> a.remoteInputs != null && a.remoteInputs.isNotEmpty() }
            svc.onNotif(title, text, n.contentIntent, pkg, reply)
        } catch (e: Exception) {}
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        try {
            val pkg = sbn.packageName
            val title = sbn.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            if (rec.any { pkg.contains(it) } || ((pkg.contains("systemui") || pkg.contains("android.system")) && isRecText(title))) OverlayService.inst?.onRec(false)
            val tx = sbn.notification.extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString() ?: ""
            if ((pkg.contains("dialer") || pkg.contains("incallui") || pkg.contains("telecom") || pkg.contains("contacts") || pkg.contains("phone")) && ((title + tx).contains("запис", true) || (title + tx).contains("record", true))) OverlayService.inst?.onCallRec(false)
        } catch (e: Exception) {}
    }
}
