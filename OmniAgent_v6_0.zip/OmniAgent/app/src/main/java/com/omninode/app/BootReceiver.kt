package com.omninode.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Settings.canDrawOverlays(c) && (Prefs.b(c, "core_on") || Prefs.b(c, "island_on") || Prefs.b(c, "bg_on"))) try { c.startForegroundService(Intent(c, OverlayService::class.java)) } catch (e: Exception) {}
    }
}
