package com.omninode.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val st = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val num = i.getStringExtra("incoming_number")
        OverlayService.inst?.onCall(st, num)
    }
}
