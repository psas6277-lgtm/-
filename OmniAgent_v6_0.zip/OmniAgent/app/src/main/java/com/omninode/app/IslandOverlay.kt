package com.omninode.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout

/** Dynamic Island поверх приложений: чёрная капсула из веб-части (index.html#island), окно подгоняется под размер капсулы. */
class IslandOverlay(private val ctx: Context, private val wm: WindowManager) {
    private val h = Handler(Looper.getMainLooper())
    private var frame: FrameLayout? = null
    private var web: WebView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var curW = 0
    private var curH = 0
    private var wantW = 0
    private var wantH = 0
    private var focusable = false
    private var paused = false
    /** Сдвиг окна от положения у камеры, dp. Задаётся из настроек или перетаскиванием. */
    private var ox = 0
    private var oy = 0
    private var moving = false
    private var expandedNow = false
    private var lastOutside = 0L
    var hiddenByApp = false
        set(v) { field = v; apply() }
    private var shrink: Runnable? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
    private fun statusH(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else dp(24)
    }

    fun attach() {
        if (frame != null) return
        val c = ContextThemeWrapper(ctx, android.R.style.Theme_DeviceDefault)
        val f = object : FrameLayout(c) {
            private var dX = 0f
            private var dY = 0f
            private var sx = 0
            private var sy = 0
            override fun onInterceptTouchEvent(e: MotionEvent): Boolean = moving || super.onInterceptTouchEvent(e)
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (!moving) return super.onTouchEvent(e)
                val d = ctx.resources.displayMetrics.density
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dX = e.rawX; dY = e.rawY; sx = ox; sy = oy }
                    MotionEvent.ACTION_MOVE -> dragTo(sx + ((e.rawX - dX) / d).toInt(), sy + ((e.rawY - dY) / d).toInt())
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endMove()
                }
                return true
            }
            override fun dispatchTouchEvent(e: MotionEvent): Boolean {
                if (moving && e.action == MotionEvent.ACTION_OUTSIDE) return true
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    // раньше JS вызывался на каждое касание где угодно на экране — это и тормозило телефон
                    val now = android.os.SystemClock.uptimeMillis()
                    if (expandedNow && now - lastOutside > 250) {
                        lastOutside = now
                        web?.evaluateJavascript("window.OmniIsland&&OmniIsland.close&&OmniIsland.close()", null)
                    }
                    return true
                }
                return super.dispatchTouchEvent(e)
            }
        }
        val w = WebView(c)
        WebSetup.setup(w, ctx)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        w.overScrollMode = View.OVER_SCROLL_NEVER
        OverlayService.webs.add(w)
        f.addView(w, FrameLayout.LayoutParams(-1, -1))
        val p = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = 0
        applyCutout(p)
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        f.visibility = View.INVISIBLE
        try { wm.addView(f, p) } catch (e: Exception) { OverlayService.webs.remove(w); w.destroy(); return }
        frame = f; web = w; lp = p
        w.loadUrl("https://appassets.androidplatform.net/assets/index.html#island")
    }


    private var lastCut = intArrayOf(0, 0, 0)

    /** Вырез камеры: [смещение центра от середины экрана px, верх px, низ px]. Нули, если выреза нет. */
    fun cutout(): IntArray {
        try {
            val dm = ctx.resources.displayMetrics
            var w = dm.widthPixels
            var cut: android.view.DisplayCutout? = null
            if (Build.VERSION.SDK_INT >= 30) {
                val m = wm.currentWindowMetrics
                cut = m.windowInsets.displayCutout
                w = m.bounds.width()
            }
            // запасные источники: окно уже на экране → rootWindowInsets, иначе Display.getCutout()
            if (cut == null && Build.VERSION.SDK_INT >= 28) cut = frame?.rootWindowInsets?.displayCutout
            if (cut == null && Build.VERSION.SDK_INT >= 29) {
                cut = try { (ctx.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager).getDisplay(0)?.cutout } catch (e: Exception) { null }
            }
            val sh = statusH()
            val r = cut?.boundingRects?.filter { it.top <= sh && it.width() > 0 }?.minByOrNull { Math.abs(it.centerX() - w / 2) }
            if (r != null) {
                lastCut = intArrayOf(r.centerX() - w / 2, r.top, r.bottom)
                return lastCut
            }
        } catch (e: Exception) {}
        return lastCut   // последнее известное значение, чтобы остров не «прыгал» при пустом ответе системы
    }

    private fun applyCutout(p: WindowManager.LayoutParams) {
        val dm = ctx.resources.displayMetrics
        val maxX = ((dm.widthPixels - p.width) / 2).coerceAtLeast(0)
        p.x = (cutout()[0] + dp(ox)).coerceIn(-maxX, maxX)
        p.y = dp(oy).coerceIn(0, (dm.heightPixels - p.height).coerceAtLeast(0))
    }

    /** Позиция из веб-части: "x,y" в dp. */
    fun setPos(m: String) {
        val a = m.split(",").map { it.trim().toIntOrNull() ?: 0 }
        ox = a.getOrElse(0) { 0 }; oy = a.getOrElse(1) { 0 }.coerceAtLeast(0)
        if (!moving && frame != null) layout(maxOf(curW, 1), maxOf(curH, 1))
    }

    private fun dragTo(nx: Int, ny: Int) {
        ox = nx; oy = ny.coerceAtLeast(0)
        layout(maxOf(curW, 1), maxOf(curH, 1))
        val p = lp ?: return
        val d = ctx.resources.displayMetrics.density
        ox = Math.round((p.x - cutout()[0]) / d); oy = Math.round(p.y / d)   // с учётом границ экрана
    }

    /** Остров можно двигать пальцем, он виден поверх любых приложений (и нашего). */
    fun beginMove() {
        if (frame == null) return
        moving = true; wake(); apply()
        web?.evaluateJavascript("window.OmniIsland&&OmniIsland.moveMode&&OmniIsland.moveMode(true)", null)
    }

    fun endMove() {
        if (!moving) return
        moving = false
        OverlayService.emit("try{OmniIsland.posSet(" + ox + "," + oy + ");OmniIsland.moveMode(false)}catch(e){}")
        apply()
    }

    /** Значение для веб-части в dp: "смещение,верх,низ". */
    fun cutoutDp(): String { val c = cutout(); val d = ctx.resources.displayMetrics.density; return c.joinToString(",") { Math.round(it / d).toString() } }

    private fun baseFlags(): Int {
        var fl = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (expandedNow) fl = fl or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        if (!focusable) fl = fl or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return fl
    }

    /** Размер из веб-части: "w,h,bubble,expanded,top" в dp. */
    fun resize(msg: String) {
        val a = msg.split(",").map { it.trim().toIntOrNull() ?: 0 }
        val w = a.getOrElse(0) { 0 }; val hh = a.getOrElse(1) { 0 }
        val bk = a.getOrElse(2) { 0 }; val top = a.getOrElse(4) { 0 }
        expandedNow = a.getOrElse(3) { 0 } == 1
        if (w <= 0 || hh <= 0) { wantW = 0; wantH = 0; apply(); return }
        val dm = ctx.resources.displayMetrics
        val pad = dp(14)
        var nw = dp(w) + pad * 2 + (if (bk == 1) dp(112) else 0)
        var nh = dp(top) + dp(hh) + pad * 2
        nw = nw.coerceAtMost(dm.widthPixels)
        nh = nh.coerceAtMost(dm.heightPixels - statusH())
        wantW = nw; wantH = nh
        apply()
    }

    private fun layout(w: Int, hh: Int) {
        val p = lp ?: return
        val f = frame ?: return
        p.width = w; p.height = hh
        applyCutout(p)
        try { wm.updateViewLayout(f, p) } catch (e: Exception) {}
        curW = w; curH = hh
    }

    private fun apply() {
        val f = frame ?: return
        val p = lp ?: return
        shrink?.let { h.removeCallbacks(it) }
        if (wantW <= 0 || wantH <= 0 || (hiddenByApp && !moving)) {
            f.visibility = View.INVISIBLE
            p.flags = baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            layout(1, 1)
            if (wantW <= 0 && !paused) { try { web?.onPause() } catch (e: Exception) {}; paused = true }
            return
        }
        if (paused) { try { web?.onResume() } catch (e: Exception) {}; paused = false }
        p.flags = baseFlags()
        f.visibility = View.VISIBLE
        if (wantW >= curW || wantH >= curH) {
            layout(maxOf(wantW, curW), maxOf(wantH, curH))
            if (wantW < curW || wantH < curH) schedule()
        } else schedule()
    }

    private fun schedule() {
        val r = Runnable { if (wantW > 0 && (!hiddenByApp || moving)) layout(wantW, wantH) }
        shrink = r
        h.postDelayed(r, 700)
    }

    fun wake() {
        if (paused) { try { web?.onResume() } catch (e: Exception) {}; paused = false }
    }

    fun setFocusable(on: Boolean) {
        focusable = on
        val p = lp ?: return
        p.flags = baseFlags()
        if (wantW <= 0 || (hiddenByApp && !moving)) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        frame?.let { try { wm.updateViewLayout(it, p) } catch (e: Exception) {} }
        if (on) web?.requestFocus()
    }

    fun reload() { wake(); web?.reload() }

    fun detach() {
        shrink?.let { h.removeCallbacks(it) }
        frame?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        web?.let { OverlayService.webs.remove(it); try { it.destroy() } catch (e: Exception) {} }
        frame = null; web = null; lp = null
    }
}
